G04 Layer: TopSolderMaskLayer*
G04 EasyEDA v6.5.61, 2026-11-17 21:18:13*
G04 edce0814d9ec48be91d4c49da6c15ef4,9c416354eb984020824aaf9c885bead6,10*
G04 Gerber Generator version 0.2*
G04 Scale: 100 percent, Rotated: No, Reflected: No *
G04 Dimensions in millimeters *
G04 leading zeros omitted , absolute positions ,4 integer and 5 decimal *
%FSLAX45Y45*%
%MOMM*%

%ADD10C,7.0016*%
%ADD11O,10.10158X4.101592*%
%ADD12C,4.3016*%
%ADD13C,0.0104*%

%LPD*%
D10*
G01*
X0Y989990D03*
D11*
G01*
X4050004Y-899998D03*
D12*
G01*
X-4999989Y1699996D03*
G01*
X-4999989Y-1699996D03*
G01*
X4999990Y-1699996D03*
G01*
X4999990Y1699996D03*
M02*
