G04 Layer: TopSolderMaskLayer*
G04 EasyEDA v6.5.61, 2026-11-17 21:18:13*
G04 c8b4375fa0744d07b8b8dddf5d60334d,9c416354eb984020824aaf9c885bead6,10*
G04 Gerber Generator version 0.2*
G04 Scale: 100 percent, Rotated: No, Reflected: No *
G04 Dimensions in millimeters *
G04 leading zeros omitted , absolute positions ,4 integer and 5 decimal *
%FSLAX45Y45*%
%MOMM*%

%ADD10O,2.701595X1.201598*%
%ADD11O,0.0105X1.201598*%

%LPD*%
D10*
G01*
X3499993Y-1059992D03*
M02*
